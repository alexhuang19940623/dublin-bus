from flask import Flask, send_from_directory, render_template, jsonify, request
import json
import pymysql

app = Flask(__name__)

root_dir = r'E:\Documents\test'


def execute_sql_script(sql):
    db = pymysql.connect(host='localhost',
                         user='root',
                         password='123456',
                         database='project',
                         charset='utf8')
    cursor = db.cursor()
    cursor.execute(sql)
    data = list(cursor.fetchall())
    col = cursor.description
    col = [[x[0] for x in col]]
    db.commit()
    db.close()
    col.extend(data)
    return col


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/query', methods=['post'])
def query():
    sql = json.loads(request.data)['sql']
    try:
        re_data = {"data": execute_sql_script(sql)}
    except:
        re_data = {'error': 'SQL syntax error!'}
    return jsonify(re_data)


app.run(debug=True)
